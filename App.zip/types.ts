
export enum AppView {
  DASHBOARD = 'DASHBOARD',
  CLASSES = 'CLASSES',
  STUDENTS = 'STUDENTS',
  TEACHERS = 'TEACHERS',
  CATEGORIES = 'CATEGORIES',
  ATTENDANCE = 'ATTENDANCE',
  REPORTS = 'REPORTS',

}

export interface Category {
  id: string;
  name: string;
  color?: string;
}

export interface Teacher {
  id: string;
  name: string;
  phone: string;
  active: boolean;
  email?: string;
}

export interface Class {
  id: string;
  name: string;
  teacher: string;
  category: string;
}

export interface Student {
  id: string;
  name: string;
  classId: string;
  birthDate: string;
  active: boolean;
}

export interface AttendanceRecord {
  id: string;
  date: string;
  classId: string;
  presentStudentIds: string[];
  bibleCount: number;
  titheAmount: number;
  visitorCount: number;
  lessonTheme: string;
}

export interface DashboardStats {
  totalStudents: number;
  totalClasses: number;
  averageAttendance: number;
  totalTithes: number;
}
