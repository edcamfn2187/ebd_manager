
import React, { useState, useEffect } from 'react';
import { supabase } from '../services/supabase';
import { Profile, UserRole } from '../types';

export const UserManagement: React.FC = () => {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAddingUser, setIsAddingUser] = useState(false);
  
  // Form states
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newRole, setNewRole] = useState<UserRole>('TEACHER');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchProfiles();
  }, []);

  const fetchProfiles = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('full_name', { ascending: true });
      
      if (error) throw error;
      setProfiles(data || []);
    } catch (err) {
      console.error('Erro ao buscar perfis:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    try {
      // 1. Criar o usuário no Supabase Auth (Nota: Em produção, isso pode deslogar o admin se não usar Admin API)
      // Para fins de UI e fluxo de "superbanco", vamos focar na inserção da tabela de perfis
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: newEmail,
        password: newPassword,
        options: {
          data: {
            full_name: newName,
            phone: newPhone,
            role: newRole
          }
        }
      });

      if (authError) throw authError;

      // 2. Atualizar a lista local
      if (authData.user) {
        const newProfile: Profile = {
          id: authData.user.id,
          email: newEmail,
          full_name: newName,
          phone: newPhone,
          role: newRole,
          created_at: new Date().toISOString()
        };
        setProfiles([newProfile, ...profiles]);
      }

      alert('Usuário pré-cadastrado com sucesso! O novo usuário deve confirmar o e-mail (se habilitado) ou já pode logar.');
      setIsAddingUser(false);
      resetForm();
    } catch (err: any) {
      alert(`Erro ao criar usuário: ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  const resetForm = () => {
    setNewName('');
    setNewEmail('');
    setNewPhone('');
    setNewPassword('');
    setNewRole('TEACHER');
  };

  const toggleRole = async (profile: Profile) => {
    const newRole: UserRole = profile.role === 'ADMIN' ? 'TEACHER' : 'ADMIN';
    if (!confirm(`Deseja alterar o cargo de ${profile.full_name} para ${newRole}?`)) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ role: newRole })
        .eq('id', profile.id);

      if (error) throw error;
      setProfiles(profiles.map(p => p.id === profile.id ? { ...p, role: newRole } : p));
    } catch (err) {
      alert('Erro ao atualizar cargo.');
    }
  };

  if (loading) return <div className="p-10 text-center animate-pulse">Carregando usuários...</div>;

  return (
    <div className="space-y-6">
      {/* Formulário de Adição (Modal style) */}
      {isAddingUser && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-[40px] shadow-2xl w-full max-w-lg overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="bg-indigo-600 p-8 text-white">
              <h3 className="text-2xl font-black">Cadastrar Novo Acesso</h3>
              <p className="text-indigo-100 text-sm opacity-80">Crie um novo login para Admin ou Professor</p>
            </div>
            
            <form onSubmit={handleCreateUser} className="p-8 space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nome Completo</label>
                <input 
                  type="text" 
                  required
                  value={newName}
                  onChange={e => setNewName(e.target.value)}
                  className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500/20 font-medium"
                  placeholder="Nome do usuário"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">E-mail / Login</label>
                  <input 
                    type="email" 
                    required
                    value={newEmail}
                    onChange={e => setNewEmail(e.target.value)}
                    className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500/20 font-medium"
                    placeholder="email@ebd.com"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Telefone</label>
                  <input 
                    type="text" 
                    required
                    value={newPhone}
                    onChange={e => setNewPhone(e.target.value)}
                    className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500/20 font-medium"
                    placeholder="(00) 00000-0000"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Senha Provisória</label>
                <input 
                  type="password" 
                  required
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500/20 font-medium"
                  placeholder="••••••••"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Cargo no Sistema</label>
                <div className="flex gap-2">
                  <button 
                    type="button" 
                    onClick={() => setNewRole('TEACHER')}
                    className={`flex-1 py-3 rounded-xl font-bold text-xs transition-all ${newRole === 'TEACHER' ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-500'}`}
                  >
                    PROFESSOR
                  </button>
                  <button 
                    type="button" 
                    onClick={() => setNewRole('ADMIN')}
                    className={`flex-1 py-3 rounded-xl font-bold text-xs transition-all ${newRole === 'ADMIN' ? 'bg-purple-600 text-white' : 'bg-slate-100 text-slate-500'}`}
                  >
                    ADMINISTRADOR
                  </button>
                </div>
              </div>

              <div className="pt-4 flex gap-3">
                <button 
                  type="button"
                  onClick={() => setIsAddingUser(false)}
                  className="flex-1 py-4 text-slate-400 font-bold hover:text-slate-600 transition-colors"
                >
                  CANCELAR
                </button>
                <button 
                  type="submit"
                  disabled={saving}
                  className="flex-1 py-4 bg-indigo-600 text-white font-black rounded-2xl shadow-xl hover:bg-indigo-700 transition-all active:scale-95 disabled:opacity-50"
                >
                  {saving ? 'CRIANDO...' : 'SALVAR LOGIN'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Tabela de Usuários */}
      <div className="bg-white rounded-[32px] border border-slate-200 shadow-sm overflow-hidden animate-in fade-in duration-500">
        <div className="p-8 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div>
            <h2 className="text-xl font-black text-slate-800">Gerenciamento de Acessos</h2>
            <p className="text-sm text-slate-500">Controle quem pode acessar o sistema e quais são suas permissões.</p>
          </div>
          <button 
            onClick={() => setIsAddingUser(true)}
            className="bg-indigo-600 text-white px-6 py-3 rounded-2xl text-xs font-black shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all flex items-center gap-2"
          >
            <span>+</span> NOVO USUÁRIO
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="text-[10px] font-black text-slate-400 uppercase tracking-widest bg-slate-50">
                <th className="px-8 py-5">Usuário</th>
                <th className="px-8 py-5">Contato</th>
                <th className="px-8 py-5">Cargo / Role</th>
                <th className="px-8 py-5 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {profiles.map(profile => (
                <tr key={profile.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center font-black text-slate-400 group-hover:bg-indigo-100 group-hover:text-indigo-600 transition-colors">
                        {profile.full_name?.[0] || '?'}
                      </div>
                      <div>
                        <p className="font-bold text-slate-700">{profile.full_name || 'Usuário sem Nome'}</p>
                        <p className="text-xs text-slate-400">{profile.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-5">
                    <p className="text-sm font-medium text-slate-600">{profile.phone || 'N/A'}</p>
                  </td>
                  <td className="px-8 py-5">
                    <span className={`px-3 py-1 rounded-lg text-[10px] font-black tracking-widest uppercase ${
                      profile.role === 'ADMIN' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'
                    }`}>
                      {profile.role}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-right">
                    <button 
                      onClick={() => toggleRole(profile)}
                      className="text-xs font-black text-indigo-600 hover:bg-indigo-50 px-4 py-2 rounded-xl transition-all"
                    >
                      ALTERAR CARGO
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {profiles.length === 0 && (
            <div className="p-20 text-center">
              <p className="text-slate-400 italic">Nenhum login encontrado no banco de dados.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
